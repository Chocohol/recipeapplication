class Direction < ActiveRecord::Base
  belongs_to :recipe
end
