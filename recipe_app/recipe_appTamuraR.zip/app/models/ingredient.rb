class Ingredient < ActiveRecord::Base
  belongs_to :recipe
end
