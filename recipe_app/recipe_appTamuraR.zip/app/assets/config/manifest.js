// manifest.js
//
// JS bundles
//= link ./javascripts/application.js
//
// CSS bundles
//= link_tree ./stylesheets
//
// Pull in all app/assets/images/ since app/views may link to them
//= link_tree ./images